(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 12);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(14));
__export(__webpack_require__(7));
__export(__webpack_require__(19));
__export(__webpack_require__(21));
__export(__webpack_require__(33));
__export(__webpack_require__(34));


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(26));
__export(__webpack_require__(27));
__export(__webpack_require__(29));
__export(__webpack_require__(31));
__export(__webpack_require__(32));


/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("apollo-server-lambda");

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var graphql_request_1 = __webpack_require__(23);
var __1 = __webpack_require__(0);
var rest_1 = __importDefault(__webpack_require__(24));
// @ts-ignore
var plugin_throttling_1 = __importDefault(__webpack_require__(25));
var utils_1 = __webpack_require__(1);
var octokitWithThrottle = rest_1.default.plugin(plugin_throttling_1.default);
var jwtManager = new __1.JwtManager();
var Github = /** @class */ (function () {
    function Github(_a) {
        var jwt = _a.jwt;
        this.repo = 'NoteHub.Notebook';
        this.userAgent = 'noted-api-v1';
        var _b = this.verifyJwtAndGetUserDetails(jwt), accessToken = _b.accessToken, owner = _b.owner;
        this.octokit = this.initOctokit(accessToken);
        this.graphql = this.initGraphQL(accessToken);
        this.owner = owner;
    }
    Github.encodeToBase64 = function (str) {
        if (!str) {
            return '';
        }
        return Buffer.from(str).toString('base64');
    };
    Github.encodeImageToBase64 = function (str) {
        if (!str) {
            return '';
        }
        return Buffer.from(str, 'binary').toString('base64');
    };
    Github.decodeFromBase64 = function (str) {
        // return Buffer.from(str, 'base64').toString('ascii')
        return Buffer.from(str, 'base64').toString();
    };
    Github.formCommitMessage = function (name, operation) {
        return "note(" + operation + " file): " + name + " - " + new Date().toDateString();
    };
    Github.prototype.initOctokitWithAccessToken = function (accessToken) {
        this.octokit = this.initOctokit(accessToken);
        return this;
    };
    Github.prototype.initGraphQL = function (accessToken) {
        var endpoint = 'https://api.github.com/graphql';
        return new graphql_request_1.GraphQLClient(endpoint, {
            headers: {
                Authorization: "bearer " + accessToken,
            },
        });
    };
    Github.prototype.initOctokit = function (accessToken) {
        var _this = this;
        return new octokitWithThrottle({
            auth: "token " + accessToken,
            throttle: {
                onAbuseLimit: function (_, options) {
                    // does not retry, only logs a warning
                    _this.octokit.log.warn("Abuse detected for request " + options.method + " " + options.url);
                },
                onRateLimit: function (retryAfter, options) {
                    _this.octokit.log.warn("Request quota exhausted for request " + options.method + " " + options.url);
                    if (options.request.retryCount === 0) {
                        // only retries once
                        console.log("Retrying after " + retryAfter + " seconds!");
                        return true;
                    }
                },
            },
            userAgent: this.userAgent,
        });
    };
    Github.prototype.verifyJwtAndGetUserDetails = function (jwt) {
        if (!jwt) {
            return {
                accessToken: '',
                owner: '',
            };
        }
        var _a = jwtManager.getJwtValues(jwt).body, encryptedAccessToken = _a.accessToken, iv = _a.iv, login = _a.login;
        return { accessToken: utils_1.decrypt(encryptedAccessToken, iv), owner: login };
    };
    return Github;
}());
exports.Github = Github;


/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("http-errors");

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(__webpack_require__(15));
__export(__webpack_require__(16));
__export(__webpack_require__(6));


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var APOLLO_ERRORS;
(function (APOLLO_ERRORS) {
    APOLLO_ERRORS["UNAUTHENTICATED"] = "UNAUTHENTICATED";
    APOLLO_ERRORS["JWT_EXPIRED"] = "JWT_EXPIRED";
    APOLLO_ERRORS["JWT_SIGNATURE_MISMATCH"] = "JWT_SIGNATURE_MISMATCH";
    APOLLO_ERRORS["REFRESH_TOKEN_EXPIRED"] = "REFRESH_TOKEN_EXPIRED";
    APOLLO_ERRORS["REFRESH_TOKEN_NOT_VALID"] = "REFRESH_TOKEN_NOT_VALID";
    APOLLO_ERRORS["INTERNAL_SERVER_ERROR"] = "INTERNAL_SERVER_ERROR";
    APOLLO_ERRORS["CONFIGURATION_NOT_FOUND"] = "CONFIGURATION_NOT_FOUND";
    APOLLO_ERRORS["UPDATE_ERROR"] = "UPDATE_ERROR";
    APOLLO_ERRORS["JWT_MISSING"] = "JWT_MISSING";
})(APOLLO_ERRORS = exports.APOLLO_ERRORS || (exports.APOLLO_ERRORS = {}));


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var aws_sdk_1 = __webpack_require__(8);
var options =  false
    ? undefined
    : {};
var dynamoDb = new aws_sdk_1.DynamoDB.DocumentClient(options);
var DynamoManager = /** @class */ (function () {
    function DynamoManager(tableName) {
        this.TableName = tableName;
    }
    DynamoManager.prototype.create = function (id, values) {
        return __awaiter(this, void 0, void 0, function () {
            var timestamp, params, response, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        timestamp = new Date().getTime();
                        params = {
                            Item: __assign({ createdAt: timestamp, id: id, updatedAt: timestamp }, values),
                            TableName: this.TableName,
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, dynamoDb.put(params).promise()];
                    case 2:
                        response = _a.sent();
                        return [2 /*return*/, response];
                    case 3:
                        error_1 = _a.sent();
                        throw new Error("DynamoDB put error: " + error_1);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    DynamoManager.prototype.read = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var params, response, error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        params = {
                            Key: {
                                id: id,
                            },
                            TableName: this.TableName,
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, dynamoDb.get(params).promise()];
                    case 2:
                        response = _a.sent();
                        return [2 /*return*/, response];
                    case 3:
                        error_2 = _a.sent();
                        throw new Error("DynamoDB read error: " + error_2);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    DynamoManager.prototype.delete = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var params, response, error_3;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        params = {
                            Key: {
                                id: id,
                            },
                            TableName: this.TableName,
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, dynamoDb.delete(params).promise()];
                    case 2:
                        response = _a.sent();
                        return [2 /*return*/, response];
                    case 3:
                        error_3 = _a.sent();
                        throw new Error("DynamoDB delete error: " + error_3);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    DynamoManager.prototype.put = function (id, values) {
        return __awaiter(this, void 0, void 0, function () {
            var timestamp, params, response, error_4;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        timestamp = new Date().getTime();
                        params = {
                            Item: __assign(__assign({}, values), { id: id, updatedAt: timestamp }),
                            TableName: this.TableName,
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, dynamoDb.put(params).promise()];
                    case 2:
                        response = _a.sent();
                        return [2 /*return*/, response];
                    case 3:
                        error_4 = _a.sent();
                        throw new Error("DynamoDB put error: " + error_4);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    DynamoManager.prototype.update = function (id, updateExpression, expressionAttributeNames, expressionAttributeValues) {
        return __awaiter(this, void 0, void 0, function () {
            var params, response, error_5;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        params = {
                            ExpressionAttributeNames: expressionAttributeNames,
                            ExpressionAttributeValues: expressionAttributeValues,
                            Key: {
                                id: id,
                            },
                            ReturnValues: 'ALL_NEW',
                            TableName: this.TableName,
                            UpdateExpression: updateExpression,
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, dynamoDb.update(params).promise()];
                    case 2:
                        response = _a.sent();
                        return [2 /*return*/, response];
                    case 3:
                        error_5 = _a.sent();
                        throw new Error("DynamoDB update error: " + error_5);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    return DynamoManager;
}());
exports.DynamoManager = DynamoManager;


/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Node_Type;
(function (Node_Type) {
    Node_Type["File"] = "FILE";
    Node_Type["Folder"] = "FOLDER";
    Node_Type["User"] = "USER";
})(Node_Type = exports.Node_Type || (exports.Node_Type = {}));
var Retext_Settings;
(function (Retext_Settings) {
    Retext_Settings["Spell"] = "SPELL";
    Retext_Settings["Equality"] = "EQUALITY";
    Retext_Settings["IndefiniteArticle"] = "INDEFINITE_ARTICLE";
    Retext_Settings["RepeatedWords"] = "REPEATED_WORDS";
    Retext_Settings["Readability"] = "READABILITY";
})(Retext_Settings = exports.Retext_Settings || (exports.Retext_Settings = {}));


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var resolvers_types_1 = __webpack_require__(9);
var DynamoManager_1 = __webpack_require__(7);
var utils_1 = __webpack_require__(1);
var ConfigurationManager = /** @class */ (function () {
    function ConfigurationManager(login) {
        var tableName = process.env.USER_CONFIGURATION_TABLE;
        if (!tableName) {
            throw new Error('No tablename set');
        }
        this.dynamoManager = new DynamoManager_1.DynamoManager(tableName);
        this.id = utils_1.encodeNodeId(resolvers_types_1.Node_Type.User, login);
    }
    ConfigurationManager.prototype.updateConfiguration = function (configuration) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dynamoManager.put(this.id, configuration)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, __assign({ id: this.id }, configuration)];
                }
            });
        });
    };
    ConfigurationManager.prototype.createConfiguration = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.dynamoManager.create(this.id)];
            });
        });
    };
    ConfigurationManager.prototype.readConfiguration = function () {
        var _a, _b, _c;
        return __awaiter(this, void 0, Promise, function () {
            var result;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0: return [4 /*yield*/, this.dynamoManager.read(this.id)];
                    case 1:
                        result = _d.sent();
                        if (!!((_a = result) === null || _a === void 0 ? void 0 : _a.Item)) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.createConfiguration()];
                    case 2:
                        _d.sent();
                        return [2 /*return*/, this.readConfiguration()];
                    case 3: return [2 /*return*/, __assign(__assign({}, result.Item), { connectedRepos: (_c = (_b = result.Item) === null || _b === void 0 ? void 0 : _b.connectedRepos, (_c !== null && _c !== void 0 ? _c : [])) })];
                }
            });
        });
    };
    return ConfigurationManager;
}());
exports.ConfigurationManager = ConfigurationManager;


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
var allowHeaders_1 = __webpack_require__(54);
function lowerCaseObjectProps(object) {
    return Object.entries(object).reduce(function (acc, _a) {
        var _b = __read(_a, 2), key = _b[0], value = _b[1];
        if (allowHeaders_1.allowHeaders.includes(key.toLowerCase())) {
            acc[key.toLowerCase()] = value;
        }
        return acc;
    }, {});
}
exports.lowerCaseObjectProps = lowerCaseObjectProps;


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var refresh_1 = __webpack_require__(13);
var server_1 = __webpack_require__(36);
var http_cors_1 = __importDefault(__webpack_require__(51));
var forwardGitRequest_1 = __webpack_require__(52);
var http_error_handler_1 = __importDefault(__webpack_require__(62));
var http_header_normalizer_1 = __importDefault(__webpack_require__(63));
var core_1 = __importDefault(__webpack_require__(64));
exports.graphql = server_1.configureServer().createHandler({
    cors: {
        credentials: true,
        origin: true,
    },
});
exports.webhook = function (event) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        console.log('we got the hook!', event);
        return [2 /*return*/, {
                body: JSON.stringify({
                    input: event,
                    message: 'Webhook received!',
                }, null, 2),
                statusCode: 200,
            }];
    });
}); };
exports.proxy = core_1.default(function (event) { return __awaiter(void 0, void 0, void 0, function () {
    return __generator(this, function (_a) {
        return [2 /*return*/, forwardGitRequest_1.forwardGitRequest(event)];
    });
}); })
    .use(http_error_handler_1.default())
    .use(http_header_normalizer_1.default())
    .use(http_cors_1.default({
    credentials: true,
    headers: 'Authorization',
    origins: [
        'http://noted-development.s3-website-eu-west-1.amazonaws.com',
        'https://notehub.xyz',
        'https://www.notehub.xyz',
    ],
}));
exports.refresh = core_1.default(function (event) { return __awaiter(void 0, void 0, void 0, function () {
    var _a, regeneratedJwt, regeneratedCookie;
    return __generator(this, function (_b) {
        switch (_b.label) {
            case 0: return [4 /*yield*/, refresh_1.refresh(event)];
            case 1:
                _a = _b.sent(), regeneratedJwt = _a.regeneratedJwt, regeneratedCookie = _a.regeneratedCookie;
                return [2 /*return*/, {
                        body: JSON.stringify(regeneratedJwt),
                        headers: {
                            'Set-Cookie': regeneratedCookie,
                        },
                        statusCode: 200,
                    }];
        }
    });
}); })
    .use(http_error_handler_1.default())
    .use(http_header_normalizer_1.default())
    .use(http_cors_1.default({
    credentials: true,
    headers: 'Authorization',
    origins: [
        'http://noted-development.s3-website-eu-west-1.amazonaws.com',
        'https://notehub.xyz',
        'https://www.notehub.xyz',
        'http://localhost:8080',
    ],
}));


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __webpack_require__(0);
var utils_1 = __webpack_require__(1);
var http_errors_1 = __importDefault(__webpack_require__(4));
function refresh(event) {
    return __awaiter(this, void 0, void 0, function () {
        var headers, cookie, authorization, jwtManager, userManager, refreshToken, _a, encryptedAccessToken, iv, accessToken, owner, regeneratedJwt, regeneratedRefreshToken, regeneratedCookie;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    headers = event.headers;
                    cookie = headers.cookie, authorization = headers.authorization;
                    if (!cookie || !authorization) {
                        throw new http_errors_1.default.Unauthorized();
                    }
                    jwtManager = new services_1.JwtManager();
                    userManager = new services_1.UserManager({ jwt: null });
                    refreshToken = utils_1.parseRefreshTokenFromCookie(cookie);
                    return [4 /*yield*/, jwtManager.getClient(refreshToken)];
                case 1:
                    _a = _b.sent(), encryptedAccessToken = _a.encryptedAccessToken, iv = _a.iv;
                    return [4 /*yield*/, jwtManager.deleteClient(refreshToken)];
                case 2:
                    _b.sent();
                    accessToken = utils_1.decrypt(encryptedAccessToken, iv);
                    return [4 /*yield*/, userManager
                            .initOctokitWithAccessToken(accessToken)
                            .readUser()];
                case 3:
                    owner = _b.sent();
                    regeneratedJwt = jwtManager
                        .createJwtWithToken(encryptedAccessToken, iv, owner)
                        .compact();
                    regeneratedRefreshToken = jwtManager.createRefreshToken();
                    return [4 /*yield*/, jwtManager.addClient(regeneratedRefreshToken, encryptedAccessToken, iv)];
                case 4:
                    _b.sent();
                    regeneratedCookie = utils_1.createCookie('refreshToken', regeneratedRefreshToken);
                    return [2 /*return*/, { regeneratedJwt: regeneratedJwt, regeneratedCookie: regeneratedCookie }];
            }
        });
    });
}
exports.refresh = refresh;


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var errors_1 = __webpack_require__(5);
var apollo_server_lambda_1 = __webpack_require__(2);
var __1 = __webpack_require__(0);
var njwt_1 = __importDefault(__webpack_require__(17));
var rand_token_1 = __importDefault(__webpack_require__(18));
var JwtManager = /** @class */ (function () {
    function JwtManager() {
        var tableName = process.env.DYNAMODB_TABLE;
        if (!tableName) {
            throw new Error('No tablename set');
        }
        this.dynamoManager = new __1.DynamoManager(tableName);
    }
    JwtManager.aWeekFromNow = function () {
        var now = new Date();
        return now.setDate(now.getDate() + 7).toString();
    };
    JwtManager.prototype.createJwtWithToken = function (encryptedAccessToken, iv, _a) {
        var login = _a.login, avatar_url = _a.avatar_url, html_url = _a.html_url;
        var jwtSigningKey = process.env.SERVERLESS_APP_JWT_SIGNING_KEY;
        var claims = {
            accessToken: encryptedAccessToken,
            avatar_url: avatar_url,
            html_url: html_url,
            iss: 'http://notehub.xyz/',
            iv: iv,
            login: login,
        };
        var jwt = njwt_1.default.create(claims, jwtSigningKey);
        jwt.setExpiration(new Date().getTime() + 10 * 1000);
        return jwt;
    };
    JwtManager.prototype.createRefreshToken = function () {
        return rand_token_1.default.uid(256);
    };
    JwtManager.prototype.getJwtValues = function (jwt) {
        var jwtSigningKey = process.env.SERVERLESS_APP_JWT_SIGNING_KEY;
        try {
            return njwt_1.default.verify(jwt, jwtSigningKey);
        }
        catch (error) {
            switch (error.message) {
                case errors_1.nJwtErrors.EXPIRED:
                    throw new errors_1.JwtExpiredError();
                case errors_1.nJwtErrors.SIGNATURE_MISMTACH:
                    throw new errors_1.JwtSignatureMismatchError();
                default:
                    throw new apollo_server_lambda_1.AuthenticationError(error.message);
            }
        }
    };
    JwtManager.prototype.getClient = function (refreshToken) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, this.dynamoManager.read(refreshToken)];
                    case 1:
                        result = _b.sent();
                        if (!((_a = result) === null || _a === void 0 ? void 0 : _a.Item)) {
                            throw new errors_1.RefreshTokenNotValidError();
                        }
                        if (this.hasClientExpired(result.Item)) {
                            throw new errors_1.RefreshTokenExpiredError();
                        }
                        return [2 /*return*/, result.Item];
                }
            });
        });
    };
    JwtManager.prototype.addClient = function (refreshToken, encryptedAccessToken, iv) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.dynamoManager.create(refreshToken, {
                        encryptedAccessToken: encryptedAccessToken,
                        expires: JwtManager.aWeekFromNow(),
                        iv: iv,
                    })];
            });
        });
    };
    JwtManager.prototype.deleteClient = function (refreshToken) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.dynamoManager.delete(refreshToken)];
            });
        });
    };
    JwtManager.prototype.hasClientExpired = function (client) {
        var now = new Date().getTime();
        var expires = client.expires;
        return expires < now;
    };
    return JwtManager;
}());
exports.JwtManager = JwtManager;


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var extensionCodes_1 = __webpack_require__(6);
// This Class has been copied from apollo-server-errors to remove
// transpiling issues in ts-jest
var ApolloError = /** @class */ (function (_super) {
    __extends(ApolloError, _super);
    function ApolloError(message, code, extensions) {
        var _this = _super.call(this, message) || this;
        if (extensions) {
            Object.keys(extensions)
                .filter(function (keyName) { return keyName !== 'message' && keyName !== 'extensions'; })
                .forEach(function (key) {
                _this[key] = extensions[key];
            });
        }
        if (!_this.name) {
            Object.defineProperty(_this, 'name', { value: 'ApolloError' });
        }
        var userProvidedExtensions = (extensions && extensions.extensions) || null;
        _this.extensions = __assign(__assign(__assign({}, extensions), userProvidedExtensions), { code: code });
        return _this;
    }
    return ApolloError;
}(Error));
exports.ApolloError = ApolloError;
var JwtMissingError = /** @class */ (function (_super) {
    __extends(JwtMissingError, _super);
    function JwtMissingError() {
        var _this = _super.call(this, 'JWT missing', extensionCodes_1.APOLLO_ERRORS.JWT_MISSING) || this;
        Object.defineProperty(_this, 'name', { value: 'JwtMissing' });
        return _this;
    }
    return JwtMissingError;
}(ApolloError));
exports.JwtMissingError = JwtMissingError;
var JwtExpiredError = /** @class */ (function (_super) {
    __extends(JwtExpiredError, _super);
    function JwtExpiredError() {
        var _this = _super.call(this, 'JWT has expired', extensionCodes_1.APOLLO_ERRORS.JWT_EXPIRED) || this;
        Object.defineProperty(_this, 'name', { value: 'JwtExpired' });
        return _this;
    }
    return JwtExpiredError;
}(ApolloError));
exports.JwtExpiredError = JwtExpiredError;
var JwtSignatureMismatchError = /** @class */ (function (_super) {
    __extends(JwtSignatureMismatchError, _super);
    function JwtSignatureMismatchError() {
        var _this = _super.call(this, 'JWT signature mismatch', extensionCodes_1.APOLLO_ERRORS.JWT_SIGNATURE_MISMATCH) || this;
        Object.defineProperty(_this, 'name', { value: 'JwtSignatureMismatch' });
        return _this;
    }
    return JwtSignatureMismatchError;
}(ApolloError));
exports.JwtSignatureMismatchError = JwtSignatureMismatchError;
var RefreshTokenExpiredError = /** @class */ (function (_super) {
    __extends(RefreshTokenExpiredError, _super);
    function RefreshTokenExpiredError() {
        var _this = _super.call(this, 'Refresh Token has expired', extensionCodes_1.APOLLO_ERRORS.REFRESH_TOKEN_EXPIRED) || this;
        Object.defineProperty(_this, 'name', { value: 'RefreshTokenExpired' });
        return _this;
    }
    return RefreshTokenExpiredError;
}(ApolloError));
exports.RefreshTokenExpiredError = RefreshTokenExpiredError;
var RefreshTokenNotValidError = /** @class */ (function (_super) {
    __extends(RefreshTokenNotValidError, _super);
    function RefreshTokenNotValidError() {
        var _this = _super.call(this, 'Refresh Token is not valid', extensionCodes_1.APOLLO_ERRORS.REFRESH_TOKEN_NOT_VALID) || this;
        Object.defineProperty(_this, 'name', { value: 'RefreshTokenNotValid' });
        return _this;
    }
    return RefreshTokenNotValidError;
}(ApolloError));
exports.RefreshTokenNotValidError = RefreshTokenNotValidError;
var ConfigurationNotFoundError = /** @class */ (function (_super) {
    __extends(ConfigurationNotFoundError, _super);
    function ConfigurationNotFoundError() {
        var _this = _super.call(this, 'Configuration not found', extensionCodes_1.APOLLO_ERRORS.CONFIGURATION_NOT_FOUND) || this;
        Object.defineProperty(_this, 'name', { value: 'ConfigurationNotFound' });
        return _this;
    }
    return ConfigurationNotFoundError;
}(ApolloError));
exports.ConfigurationNotFoundError = ConfigurationNotFoundError;
var UpdateError = /** @class */ (function (_super) {
    __extends(UpdateError, _super);
    function UpdateError() {
        var _this = _super.call(this, 'Update error', extensionCodes_1.APOLLO_ERRORS.UPDATE_ERROR) || this;
        Object.defineProperty(_this, 'name', { value: 'UpdateError' });
        return _this;
    }
    return UpdateError;
}(ApolloError));
exports.UpdateError = UpdateError;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.nJwtErrors = {
    EXPIRED: 'Jwt is expired',
    KEY_RESOLVER_ERROR: 'Error while resolving signing key for kid "%s"',
    NOT_ACTIVE: 'Jwt not active',
    PARSE_ERROR: 'Jwt cannot be parsed',
    SIGNATURE_ALGORITHM_MISMTACH: 'Unexpected signature algorithm',
    SIGNATURE_MISMTACH: 'Signature verification failed',
    SIGNING_KEY_REQUIRED: 'Signing key is required',
    UNSUPPORTED_SIGNING_ALG: 'Unsupported signing algorithm',
};


/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("njwt");

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = require("rand-token");

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var aws_sdk_1 = __webpack_require__(8);
var uuid_1 = __webpack_require__(20);
var options =  false
    ? undefined
    : {
        accessKeyId: process.env.SERVERLESS_APP_ACCESS_KEY_ID,
        secretAccessKey: process.env.SERVERLESS_APP_SECRET_ACCESS_KEY,
        signatureVersion: 'v4',
    };
var s3 = new aws_sdk_1.S3(options);
var S3Manager = /** @class */ (function () {
    function S3Manager(bucket) {
        this.Bucket = bucket;
    }
    S3Manager.prototype.createSignedUrl = function () {
        return __awaiter(this, void 0, void 0, function () {
            var params, url, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        params = {
                            ACL: 'public-read',
                            Bucket: this.Bucket,
                            Key: uuid_1.v4(),
                        };
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, s3.getSignedUrlPromise('putObject', params)];
                    case 2:
                        url = _a.sent();
                        return [2 /*return*/, url];
                    case 3:
                        error_1 = _a.sent();
                        throw new Error("S3 getSignedUrl error: " + error_1);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    return S3Manager;
}());
exports.S3Manager = S3Manager;


/***/ }),
/* 20 */
/***/ (function(module, exports) {

module.exports = require("uuid");

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
var resolvers_types_1 = __webpack_require__(9);
var GetCommit_1 = __webpack_require__(22);
var Base_1 = __webpack_require__(3);
var utils_1 = __webpack_require__(1);
var FileManager = /** @class */ (function (_super) {
    __extends(FileManager, _super);
    function FileManager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FileManager.prototype.readFile = function (path) {
        return __awaiter(this, void 0, Promise, function () {
            var data, content;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.octokit.repos.getContents({
                            owner: this.owner,
                            path: path,
                            repo: this.repo,
                        })];
                    case 1:
                        data = (_a.sent()).data;
                        if (data.type === 'file') {
                            content = Base_1.Github.decodeFromBase64(data.content);
                            return [2 /*return*/, __assign(__assign({}, data), { content: content, excerpt: content.substring(0, 50) + "...", filename: data.name, id: utils_1.encodeNodeId(resolvers_types_1.Node_Type.File, path), type: resolvers_types_1.Node_Type.File })];
                        }
                        return [2 /*return*/, __assign(__assign({}, data), { filename: data.name, id: utils_1.encodeNodeId(resolvers_types_1.Node_Type.Folder, path), type: resolvers_types_1.Node_Type.Folder })];
                }
            });
        });
    };
    FileManager.prototype.readFiles = function () {
        return __awaiter(this, void 0, Promise, function () {
            var _a, oid, tree, error_1;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, this.graphql.request(GetCommit_1.GetCommit, {
                                name: this.repo,
                                owner: this.owner,
                            })];
                    case 1:
                        _a = __read.apply(void 0, [(_b.sent()).repository.object.history.nodes, 1]), oid = _a[0].oid;
                        return [4 /*yield*/, this.octokit.git.getTree({
                                owner: this.owner,
                                recursive: 1,
                                repo: this.repo,
                                tree_sha: oid,
                            })];
                    case 2:
                        tree = (_b.sent()).data.tree;
                        return [2 /*return*/, tree.map(function (node) {
                                var type = node.type === 'blob' ? resolvers_types_1.Node_Type.File : resolvers_types_1.Node_Type.Folder;
                                return __assign(__assign({}, node), { id: utils_1.encodeNodeId(type, node.path), type: type });
                            })];
                    case 3:
                        error_1 = _b.sent();
                        // Repo has been setup but no changes have been made to it
                        if (error_1.message === "Cannot read property 'history' of null") {
                            return [2 /*return*/, []];
                        }
                        // All files within the repo have been deleted
                        if (error_1.message === 'Not Found') {
                            return [2 /*return*/, []];
                        }
                        throw new Error(error_1);
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    FileManager.prototype.createFile = function (path, content, isImage) {
        if (isImage === void 0) { isImage = false; }
        return __awaiter(this, void 0, Promise, function () {
            var file, error_2, error_3;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.readFile(path)];
                    case 1:
                        file = _a.sent();
                        if (file.sha) {
                            throw new Error('file already exists');
                        }
                        return [3 /*break*/, 3];
                    case 2:
                        error_2 = _a.sent();
                        // We want to swallow these error messages and throw
                        // everything else
                        if (!error_2.message.includes('This repository is empty.') &&
                            !error_2.message.includes('Not Found')) {
                            throw error_2;
                        }
                        return [3 /*break*/, 3];
                    case 3:
                        _a.trys.push([3, 5, , 6]);
                        return [4 /*yield*/, this.octokit.repos.createFile({
                                content: isImage
                                    ? Base_1.Github.encodeImageToBase64(content)
                                    : Base_1.Github.encodeToBase64(content),
                                message: Base_1.Github.formCommitMessage(path, 'create'),
                                owner: this.owner,
                                path: path,
                                repo: this.repo,
                            })];
                    case 4:
                        _a.sent();
                        return [3 /*break*/, 6];
                    case 5:
                        error_3 = _a.sent();
                        if (!error_3.message.includes('"sha" wasn\'t supplied')) {
                            throw error_3;
                        }
                        return [3 /*break*/, 6];
                    case 6: return [2 /*return*/, this.readFile(path)];
                }
            });
        });
    };
    FileManager.prototype.updateFile = function (_a) {
        var path = _a.path, content = _a.content;
        var _b;
        return __awaiter(this, void 0, Promise, function () {
            var _c, sha, originalContent;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0: return [4 /*yield*/, this.readFile(path)];
                    case 1:
                        _c = _d.sent(), sha = _c.sha, originalContent = _c.content;
                        return [4 /*yield*/, this.octokit.repos.updateFile({
                                content: Base_1.Github.encodeToBase64((_b = (content !== null && content !== void 0 ? content : originalContent), (_b !== null && _b !== void 0 ? _b : ''))),
                                message: Base_1.Github.formCommitMessage(path, 'update'),
                                owner: this.owner,
                                path: path,
                                repo: this.repo,
                                sha: sha,
                            })];
                    case 2:
                        _d.sent();
                        return [2 /*return*/, this.readFile(path)];
                }
            });
        });
    };
    FileManager.prototype.deleteFile = function (path) {
        return __awaiter(this, void 0, Promise, function () {
            var file;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.readFile(path)];
                    case 1:
                        file = _a.sent();
                        return [4 /*yield*/, this.octokit.repos.deleteFile({
                                message: Base_1.Github.formCommitMessage(path, 'delete'),
                                owner: this.owner,
                                path: path,
                                repo: this.repo,
                                sha: file.sha,
                            })];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, file];
                }
            });
        });
    };
    FileManager.prototype.moveFile = function (_a) {
        var path = _a.path, newPath = _a.newPath;
        return __awaiter(this, void 0, Promise, function () {
            var error_4, content;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 2, , 6]);
                        return [4 /*yield*/, this.readFile(newPath)];
                    case 1:
                        _b.sent();
                        return [3 /*break*/, 6];
                    case 2:
                        error_4 = _b.sent();
                        if (!(error_4.message === 'Not Found')) return [3 /*break*/, 5];
                        return [4 /*yield*/, this.readFile(path)];
                    case 3:
                        content = (_b.sent()).content;
                        return [4 /*yield*/, this.deleteFile(path)];
                    case 4:
                        _b.sent();
                        return [2 /*return*/, this.createFile(newPath, content)];
                    case 5: return [3 /*break*/, 6];
                    case 6: throw new Error('File already exists');
                }
            });
        });
    };
    return FileManager;
}(Base_1.Github));
exports.FileManager = FileManager;


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.GetCommit = "\n  query GetCommit($owner: String!, $name: String!) {\n    repository(owner: $owner, name: $name) {\n      object(expression: \"main\") {\n        ... on Commit {\n          history(first: 1) {\n            nodes {\n              oid\n            }\n          }\n        }\n      }\n    }\n  }\n";


/***/ }),
/* 23 */
/***/ (function(module, exports) {

module.exports = require("graphql-request");

/***/ }),
/* 24 */
/***/ (function(module, exports) {

module.exports = require("@octokit/rest");

/***/ }),
/* 25 */
/***/ (function(module, exports) {

module.exports = require("@octokit/plugin-throttling");

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function getEnv(env) {
    return  false
        ? undefined
        : process.env[env];
}
exports.getEnv = getEnv;


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var apollo_server_lambda_1 = __webpack_require__(2);
var cookie_1 = __importDefault(__webpack_require__(28));
exports.createCookie = function (name, value) {
    return cookie_1.default.serialize(name, value, {
        httpOnly: true,
        maxAge: 60 * 60 * 24 * 7,
        sameSite: 'none',
        secure: true,
    });
};
exports.addCookie = function (context, name, value) {
    var cookie = exports.createCookie(name, value);
    context.addHeaders = [{ key: 'Set-Cookie', value: cookie }];
};
exports.removeCookie = function (context, name) {
    var cookie = cookie_1.default.serialize(name, '', {
        expires: new Date('August 19, 1975 23:15:30'),
        httpOnly: true,
        sameSite: 'none',
        secure: true,
    });
    context.addHeaders = [{ key: 'Set-Cookie', value: cookie }];
};
exports.parseRefreshTokenFromCookie = function (cookie) {
    if (!cookie) {
        throw new Error('No cookie present');
    }
    var parsedCookie = cookie_1.default.parse(cookie);
    if (!parsedCookie.refreshToken) {
        throw new apollo_server_lambda_1.AuthenticationError('No refreshToken');
    }
    return parsedCookie.refreshToken;
};


/***/ }),
/* 28 */
/***/ (function(module, exports) {

module.exports = require("cookie");

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var crypto_1 = __importDefault(__webpack_require__(30));
var tokenSigningKey = process.env.SERVERLESS_APP_TOKEN_SIGNING_KEY;
var key = crypto_1.default
    .createHash('sha256')
    .update(String(tokenSigningKey))
    .digest('base64')
    .substr(0, 32);
exports.encrypt = function (value) {
    var iv = new Buffer(crypto_1.default.randomBytes(8)).toString('hex');
    var cipher = crypto_1.default.createCipheriv('aes-256-ctr', key, iv);
    var crypted = cipher.update(value, 'utf8', 'hex');
    return { value: "" + crypted + cipher.final('hex'), iv: iv };
};
exports.decrypt = function (value, iv) {
    var decipher = crypto_1.default.createDecipheriv('aes-256-ctr', key, iv);
    var dec = decipher.update(value, 'hex', 'utf8');
    return "" + dec + decipher.final('utf8');
};


/***/ }),
/* 30 */
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.addHeadersFromContext = {
    requestDidStart: function () {
        return {
            willSendResponse: function (requestContext) {
                var _a = requestContext.context.context.addHeaders, addHeaders = _a === void 0 ? [] : _a;
                addHeaders.forEach(function (_a) {
                    var key = _a.key, value = _a.value;
                    requestContext.response.http.headers.append(key, value);
                });
                return requestContext;
            },
        };
    },
};


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spread = (this && this.__spread) || function () {
    for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
function encodeNodeId(type) {
    var parts = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        parts[_i - 1] = arguments[_i];
    }
    return Buffer.from(__spread([type], parts).join(':')).toString('base64');
}
exports.encodeNodeId = encodeNodeId;


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var Base_1 = __webpack_require__(3);
var RepoManager = /** @class */ (function (_super) {
    __extends(RepoManager, _super);
    function RepoManager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RepoManager.prototype.readRepo = function (name) {
        return __awaiter(this, void 0, Promise, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.octokit.repos.get({
                            owner: this.owner,
                            repo: name,
                        })];
                    case 1:
                        data = (_a.sent()).data;
                        return [2 /*return*/, data];
                }
            });
        });
    };
    RepoManager.prototype.listRepos = function () {
        return __awaiter(this, void 0, Promise, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.octokit.repos.list({
                            per_page: 100,
                            sort: 'updated',
                        })];
                    case 1:
                        data = (_a.sent()).data;
                        return [2 /*return*/, data];
                }
            });
        });
    };
    RepoManager.prototype.createRepo = function () {
        return __awaiter(this, void 0, Promise, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.octokit.repos.createForAuthenticatedUser({
                            description: 'A place to keep all notes created by Notehub',
                            name: this.repo,
                            private: false,
                        })];
                    case 1:
                        data = (_a.sent()).data;
                        return [2 /*return*/, data];
                }
            });
        });
    };
    RepoManager.prototype.updateRepo = function (_a) {
        var name = _a.name, updatedDescription = _a.description, updatedPrivate = _a.private;
        return __awaiter(this, void 0, Promise, function () {
            var _b, description, isPrivate, data;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0: return [4 /*yield*/, this.readRepo(name)];
                    case 1:
                        _b = _c.sent(), description = _b.description, isPrivate = _b.private;
                        return [4 /*yield*/, this.octokit.repos.update({
                                description: updatedDescription || description || '',
                                owner: this.owner,
                                private: (updatedPrivate !== null && updatedPrivate !== void 0 ? updatedPrivate : isPrivate),
                                repo: this.repo,
                            })];
                    case 2:
                        data = (_c.sent()).data;
                        return [2 /*return*/, data];
                }
            });
        });
    };
    RepoManager.prototype.deleteRepo = function (name) {
        return __awaiter(this, void 0, Promise, function () {
            var originalRepo;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.readRepo(name)];
                    case 1:
                        originalRepo = _a.sent();
                        return [4 /*yield*/, this.octokit.repos.delete({
                                owner: this.owner,
                                repo: name,
                            })];
                    case 2:
                        _a.sent();
                        return [2 /*return*/, originalRepo];
                }
            });
        });
    };
    return RepoManager;
}(Base_1.Github));
exports.RepoManager = RepoManager;


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var Base_1 = __webpack_require__(3);
var axios_1 = __importDefault(__webpack_require__(35));
var GITHUB_ACCESS_TOKEN_LINK = process.env.SERVERLESS_APP_GITHUB_ACCESS_TOKEN_LINK;
var CLIENT_SECRET = process.env.SERVERLESS_APP_CLIENT_SECRET;
var CLIENT_ID = process.env.SERVERLESS_APP_CLIENT_ID;
var REDIRECT_URL = process.env.SERVERLESS_APP_REDIRECT_URL;
var UserManager = /** @class */ (function (_super) {
    __extends(UserManager, _super);
    function UserManager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    UserManager.prototype.readGithubUserAccessToken = function (code, state) {
        return __awaiter(this, void 0, void 0, function () {
            var data, includesAccessToken, _a, accessToken;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, axios_1.default.post(GITHUB_ACCESS_TOKEN_LINK, {
                            client_id: CLIENT_ID,
                            client_secret: CLIENT_SECRET,
                            code: code,
                            redirect_uri: REDIRECT_URL,
                            state: state,
                        })];
                    case 1:
                        data = (_b.sent()).data;
                        includesAccessToken = data.includes('access_token');
                        if (includesAccessToken) {
                            _a = __read(data.replace(/access_token=/gi, '').split('&'), 1), accessToken = _a[0];
                            return [2 /*return*/, accessToken];
                        }
                        else {
                            throw new Error('Error retrieving access token');
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    UserManager.prototype.readUser = function () {
        return __awaiter(this, void 0, Promise, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.octokit.users.getAuthenticated()];
                    case 1:
                        data = (_a.sent()).data;
                        return [2 /*return*/, data];
                }
            });
        });
    };
    return UserManager;
}(Base_1.Github));
exports.UserManager = UserManager;


/***/ }),
/* 35 */
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var configuration_1 = __webpack_require__(37);
var file_1 = __webpack_require__(38);
var image_1 = __webpack_require__(39);
var repo_1 = __webpack_require__(40);
var apollo_server_lambda_1 = __webpack_require__(2);
var apollo_server_lambda_2 = __webpack_require__(2);
var authorization_1 = __webpack_require__(41);
var user_1 = __webpack_require__(42);
var utils_1 = __webpack_require__(1);
var schema_1 = __webpack_require__(43);
function configureServer() {
    var resolvers = {
        Mutation: __assign(__assign(__assign(__assign({}, repo_1.RepoMutations), file_1.FileMutations), image_1.ImageMutations), configuration_1.ConfigurationMutations),
        Query: __assign(__assign(__assign(__assign(__assign(__assign({}, user_1.UserQueries), repo_1.RepoQueries), file_1.FileQueries), image_1.ImageQueries), authorization_1.AuthorizationQueries), configuration_1.ConfigurationQueries),
    };
    return new apollo_server_lambda_1.ApolloServer({
        context: function (_a) {
            var event = _a.event, context = _a.context;
            var _b, _c, _d;
            var bearerToken = (_b = event.headers) === null || _b === void 0 ? void 0 : _b.Authorization;
            var cookie = (_d = (_c = event.headers) === null || _c === void 0 ? void 0 : _c.Cookie, (_d !== null && _d !== void 0 ? _d : null));
            var jwt = bearerToken && typeof bearerToken === 'string'
                ? bearerToken.substring(7, bearerToken.length)
                : null;
            return {
                context: context,
                cookie: cookie,
                jwt: jwt,
            };
        },
        formatError: function (error) {
            var githubAuthError = error.message === 'Bad credentials';
            var formattedError = githubAuthError
                ? new apollo_server_lambda_2.AuthenticationError('You must be authorized to access this schema')
                : error;
            return formattedError;
        },
        plugins: [utils_1.addHeadersFromContext],
        resolvers: resolvers,
        typeDefs: schema_1.generateTypedefs(),
    });
}
exports.configureServer = configureServer;


/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var ConfigurationManager_1 = __webpack_require__(10);
var services_1 = __webpack_require__(0);
var errors_1 = __webpack_require__(5);
var jwtManager = new services_1.JwtManager();
exports.ConfigurationQueries = {
    readConfiguration: function (_, _1, _a) {
        var jwt = _a.jwt;
        return __awaiter(this, void 0, Promise, function () {
            var login, configurationManager;
            return __generator(this, function (_b) {
                if (!jwt) {
                    throw errors_1.JwtMissingError;
                }
                login = jwtManager.getJwtValues(jwt).body.login;
                configurationManager = new ConfigurationManager_1.ConfigurationManager(login);
                return [2 /*return*/, configurationManager.readConfiguration()];
            });
        });
    },
};
exports.ConfigurationMutations = {
    updateConfiguration: function (_, _a, _b) {
        var configuration = _a.input;
        var jwt = _b.jwt;
        return __awaiter(this, void 0, Promise, function () {
            var login, configurationManager;
            return __generator(this, function (_c) {
                if (!jwt) {
                    throw errors_1.JwtMissingError;
                }
                login = jwtManager.getJwtValues(jwt).body.login;
                configurationManager = new ConfigurationManager_1.ConfigurationManager(login);
                return [2 /*return*/, configurationManager.updateConfiguration(configuration)];
            });
        });
    },
};


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __webpack_require__(0);
exports.FileQueries = {
    readFile: function (_, _a, context) {
        var path = _a.path;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_b) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.readFile(path)];
            });
        });
    },
    readFiles: function (_, _1, context) {
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_a) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.readFiles()];
            });
        });
    },
};
exports.FileMutations = {
    createFile: function (_, _a, context) {
        var _b = _a.input, path = _b.path, content = _b.content;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_c) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.createFile(path, content)];
            });
        });
    },
    updateFile: function (_, _a, context) {
        var _b = _a.input, path = _b.path, content = _b.content;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_c) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.updateFile({ path: path, content: content })];
            });
        });
    },
    deleteFile: function (_, _a, context) {
        var path = _a.input.path;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_b) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.deleteFile(path)];
            });
        });
    },
    moveFile: function (_, _a, context) {
        var input = _a.input;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_b) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.moveFile(input)];
            });
        });
    },
};


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __webpack_require__(0);
exports.ImageQueries = {
    readImage: function (_, _a, context) {
        var path = _a.path;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_b) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.readFile(path)];
            });
        });
    },
};
exports.ImageMutations = {
    createImage: function (_, _a, context) {
        var _b = _a.input, path = _b.path, content = _b.content;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_c) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.createFile(path, content, true)];
            });
        });
    },
    updateImage: function (_, _a, context) {
        var input = _a.input;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_b) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.updateFile(input)];
            });
        });
    },
    deleteImage: function (_, _a, context) {
        var path = _a.input.path;
        return __awaiter(this, void 0, Promise, function () {
            var fileManager;
            return __generator(this, function (_b) {
                fileManager = new services_1.FileManager(context);
                return [2 /*return*/, fileManager.deleteFile(path)];
            });
        });
    },
    createSignedUrl: function () {
        return __awaiter(this, void 0, Promise, function () {
            var bucket, s3Manager;
            return __generator(this, function (_a) {
                bucket = process.env.S3_IMAGE_BUCKET;
                if (!bucket) {
                    throw new Error('No bucket set');
                }
                s3Manager = new services_1.S3Manager(bucket);
                return [2 /*return*/, s3Manager.createSignedUrl()];
            });
        });
    },
};


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __webpack_require__(0);
exports.RepoQueries = {
    readRepo: function (_, _a, context) {
        var name = _a.name;
        return __awaiter(this, void 0, Promise, function () {
            var repoManager;
            return __generator(this, function (_b) {
                repoManager = new services_1.RepoManager(context);
                return [2 /*return*/, repoManager.readRepo(name)];
            });
        });
    },
    listRepos: function (_, _1, context) {
        return __awaiter(this, void 0, Promise, function () {
            var repoManager;
            return __generator(this, function (_a) {
                repoManager = new services_1.RepoManager(context);
                return [2 /*return*/, repoManager.listRepos()];
            });
        });
    },
};
exports.RepoMutations = {
    createRepo: function (_, _1, context) {
        return __awaiter(this, void 0, Promise, function () {
            var repoManager;
            return __generator(this, function (_a) {
                repoManager = new services_1.RepoManager(context);
                return [2 /*return*/, repoManager.createRepo()];
            });
        });
    },
    updateRepo: function (_, _a, context) {
        var input = _a.input;
        return __awaiter(this, void 0, Promise, function () {
            var repoManager;
            return __generator(this, function (_b) {
                repoManager = new services_1.RepoManager(context);
                return [2 /*return*/, repoManager.updateRepo(input)];
            });
        });
    },
    deleteRepo: function (_, _a, context) {
        var name = _a.input.name;
        return __awaiter(this, void 0, Promise, function () {
            var repoManager;
            return __generator(this, function (_b) {
                repoManager = new services_1.RepoManager(context);
                return [2 /*return*/, repoManager.deleteRepo(name)];
            });
        });
    },
};


/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __webpack_require__(0);
var utils_1 = __webpack_require__(1);
var apollo_server_lambda_1 = __webpack_require__(2);
var jwtManager = new services_1.JwtManager();
exports.AuthorizationQueries = {
    login: function (_0, _1, _a) {
        var cookie = _a.cookie, rest = __rest(_a, ["cookie"]);
        return __awaiter(this, void 0, Promise, function () {
            var userManager, refreshToken, _b, encryptedAccessToken, iv, accessToken, owner;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        if (!cookie) {
                            throw new apollo_server_lambda_1.AuthenticationError('No cookie sent');
                        }
                        userManager = new services_1.UserManager(rest);
                        refreshToken = utils_1.parseRefreshTokenFromCookie(cookie);
                        return [4 /*yield*/, jwtManager.getClient(refreshToken)];
                    case 1:
                        _b = _c.sent(), encryptedAccessToken = _b.encryptedAccessToken, iv = _b.iv;
                        accessToken = utils_1.decrypt(encryptedAccessToken, iv);
                        return [4 /*yield*/, userManager
                                .initOctokitWithAccessToken(accessToken)
                                .readUser()];
                    case 2:
                        owner = _c.sent();
                        return [2 /*return*/, jwtManager
                                .createJwtWithToken(encryptedAccessToken, iv, owner)
                                .compact()];
                }
            });
        });
    },
    refresh: function (_0, _1, _a) {
        var context = _a.context, cookie = _a.cookie, rest = __rest(_a, ["context", "cookie"]);
        return __awaiter(this, void 0, Promise, function () {
            var userManager, refreshToken, _b, encryptedAccessToken, iv, accessToken, owner, regeneratedJwt, regeneratedRefreshToken;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        if (!cookie) {
                            throw new apollo_server_lambda_1.AuthenticationError('No cookie sent');
                        }
                        userManager = new services_1.UserManager(rest);
                        refreshToken = utils_1.parseRefreshTokenFromCookie(cookie);
                        return [4 /*yield*/, jwtManager.getClient(refreshToken)];
                    case 1:
                        _b = _c.sent(), encryptedAccessToken = _b.encryptedAccessToken, iv = _b.iv;
                        return [4 /*yield*/, jwtManager.deleteClient(refreshToken)];
                    case 2:
                        _c.sent();
                        accessToken = utils_1.decrypt(encryptedAccessToken, iv);
                        return [4 /*yield*/, userManager
                                .initOctokitWithAccessToken(accessToken)
                                .readUser()];
                    case 3:
                        owner = _c.sent();
                        regeneratedJwt = jwtManager
                            .createJwtWithToken(encryptedAccessToken, iv, owner)
                            .compact();
                        regeneratedRefreshToken = jwtManager.createRefreshToken();
                        return [4 /*yield*/, jwtManager.addClient(regeneratedRefreshToken, encryptedAccessToken, iv)];
                    case 4:
                        _c.sent();
                        utils_1.addCookie(context, 'refreshToken', regeneratedRefreshToken);
                        return [2 /*return*/, regeneratedJwt];
                }
            });
        });
    },
    logout: function (_0, _1, _a) {
        var context = _a.context, cookie = _a.cookie;
        return __awaiter(this, void 0, void 0, function () {
            var refreshToken;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!cookie) {
                            throw new apollo_server_lambda_1.AuthenticationError('No cookie sent');
                        }
                        refreshToken = utils_1.parseRefreshTokenFromCookie(cookie);
                        return [4 /*yield*/, jwtManager.deleteClient(refreshToken)];
                    case 1:
                        _b.sent();
                        utils_1.removeCookie(context, 'refreshToken');
                        return [2 /*return*/, 'ok'];
                }
            });
        });
    },
};


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __webpack_require__(0);
var utils_1 = __webpack_require__(1);
var ConfigurationManager_1 = __webpack_require__(10);
var jwtManager = new services_1.JwtManager();
exports.UserQueries = {
    readGithubUserAccessToken: function (_, _a, _b) {
        var code = _a.code, state = _a.state;
        var context = _b.context, rest = __rest(_b, ["context"]);
        return __awaiter(this, void 0, Promise, function () {
            var userManager, accessToken, owner, _c, value, iv, jwt, refreshToken;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        userManager = new services_1.UserManager(rest);
                        return [4 /*yield*/, userManager.readGithubUserAccessToken(code, state)];
                    case 1:
                        accessToken = _d.sent();
                        return [4 /*yield*/, userManager
                                .initOctokitWithAccessToken(accessToken)
                                .readUser()];
                    case 2:
                        owner = _d.sent();
                        _c = utils_1.encrypt(accessToken), value = _c.value, iv = _c.iv;
                        jwt = jwtManager.createJwtWithToken(value, iv, owner).compact();
                        refreshToken = jwtManager.createRefreshToken();
                        return [4 /*yield*/, jwtManager.addClient(refreshToken, value, iv)];
                    case 3:
                        _d.sent();
                        utils_1.addCookie(context, 'refreshToken', refreshToken);
                        return [2 /*return*/, jwt];
                }
            });
        });
    },
    readGithubUser: function (_0, _1, context) {
        return __awaiter(this, void 0, Promise, function () {
            var userManager, _a, id, login, rest, configurationManager, configuration;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        userManager = new services_1.UserManager(context);
                        return [4 /*yield*/, userManager.readUser()];
                    case 1:
                        _a = _b.sent(), id = _a.id, login = _a.login, rest = __rest(_a, ["id", "login"]);
                        configurationManager = new ConfigurationManager_1.ConfigurationManager(login);
                        return [4 /*yield*/, configurationManager.readConfiguration()];
                    case 2:
                        configuration = _b.sent();
                        return [2 /*return*/, __assign({ id: id, login: login, configuration: configuration }, rest)];
                }
            });
        });
    },
};


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var merge_graphql_schemas_1 = __webpack_require__(44);
function generateTypedefs() {
    var file = __webpack_require__(45);
    var image = __webpack_require__(46);
    var repo = __webpack_require__(47);
    var user = __webpack_require__(48);
    var authorization = __webpack_require__(49);
    var configuration = __webpack_require__(50);
    return merge_graphql_schemas_1.mergeTypes([file, image, repo, user, authorization, configuration], {
        all: true,
    });
}
exports.generateTypedefs = generateTypedefs;


/***/ }),
/* 44 */
/***/ (function(module, exports) {

module.exports = require("merge-graphql-schemas");

/***/ }),
/* 45 */
/***/ (function(module, exports) {


    var doc = {"kind":"Document","definitions":[{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Query"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"readFile"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"path"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"readFiles"},"arguments":[],"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}}}},"directives":[]}]},{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Mutation"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"createFile"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"CreateFileInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"updateFile"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateFileInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"deleteFile"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"DeleteFileInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"moveFile"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"MoveFileInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"Links"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"html"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"File"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"id"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"ID"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"path"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"type"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"NODE_TYPE"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"sha"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"url"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"filename"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"content"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"ModelFileConnection"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"items"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}}}}},"directives":[]}]},{"kind":"InputObjectTypeDefinition","name":{"kind":"Name","value":"CreateFileInput"},"directives":[],"fields":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"path"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"content"},"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"retextSettings"},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"RETEXT_SETTINGS"}}}},"directives":[]}]},{"kind":"InputObjectTypeDefinition","name":{"kind":"Name","value":"UpdateFileInput"},"directives":[],"fields":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"path"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"content"},"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"retextSettings"},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"RETEXT_SETTINGS"}}}},"directives":[]}]},{"kind":"InputObjectTypeDefinition","name":{"kind":"Name","value":"MoveFileInput"},"directives":[],"fields":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"path"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"newPath"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}]},{"kind":"InputObjectTypeDefinition","name":{"kind":"Name","value":"DeleteFileInput"},"directives":[],"fields":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"path"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}]},{"kind":"EnumTypeDefinition","name":{"kind":"Name","value":"NODE_TYPE"},"directives":[],"values":[{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"FILE"},"directives":[]},{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"FOLDER"},"directives":[]},{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"USER"},"directives":[]}]},{"kind":"EnumTypeDefinition","name":{"kind":"Name","value":"RETEXT_SETTINGS"},"directives":[],"values":[{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"SPELL"},"directives":[]},{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"EQUALITY"},"directives":[]},{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"INDEFINITE_ARTICLE"},"directives":[]},{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"REPEATED_WORDS"},"directives":[]},{"kind":"EnumValueDefinition","name":{"kind":"Name","value":"READABILITY"},"directives":[]}]}],"loc":{"start":0,"end":981}};
    doc.loc.source = {"body":"## Base\nextend type Query {\n  readFile(path: String!): File\n  readFiles: [File!]\n}\n\nextend type Mutation {\n  createFile(input: CreateFileInput!): File\n  updateFile(input: UpdateFileInput!): File\n  deleteFile(input: DeleteFileInput!): File\n  moveFile(input: MoveFileInput!): File\n}\n\n## Types\ntype Links {\n  html: String!\n}\n\ntype File {\n  id: ID!\n  path: String!\n  type: NODE_TYPE!\n  sha: String!\n  url: String!\n  filename: String\n  content: String\n}\n\n## Query outputs\ntype ModelFileConnection {\n  items: [File!]!\n}\n\n## Mutation inputs\ninput CreateFileInput {\n  path: String!\n  content: String\n  retextSettings: [RETEXT_SETTINGS!]\n}\n\ninput UpdateFileInput {\n  path: String!\n  content: String\n  retextSettings: [RETEXT_SETTINGS!]\n}\n\ninput MoveFileInput {\n  path: String!\n  newPath: String!\n}\n\ninput DeleteFileInput {\n  path: String!\n}\n\n## Enums\nenum NODE_TYPE {\n  FILE\n  FOLDER\n  USER\n}\n\nenum RETEXT_SETTINGS {\n  SPELL\n  EQUALITY\n  INDEFINITE_ARTICLE\n  REPEATED_WORDS\n  READABILITY\n}\n","name":"GraphQL request","locationOffset":{"line":1,"column":1}};
  

    var names = {};
    function unique(defs) {
      return defs.filter(
        function(def) {
          if (def.kind !== 'FragmentDefinition') return true;
          var name = def.name.value
          if (names[name]) {
            return false;
          } else {
            names[name] = true;
            return true;
          }
        }
      )
    }
  

      module.exports = doc;
    


/***/ }),
/* 46 */
/***/ (function(module, exports) {


    var doc = {"kind":"Document","definitions":[{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Query"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"readImage"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"path"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]}]},{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Mutation"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"createImage"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"CreateFileInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"updateImage"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateFileInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"deleteImage"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"DeleteFileInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"File"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"createSignedUrl"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]}]}],"loc":{"start":0,"end":250}};
    doc.loc.source = {"body":"## Base\nextend type Query {\n  readImage(path: String!): File\n}\n\nextend type Mutation {\n  createImage(input: CreateFileInput!): File\n  updateImage(input: UpdateFileInput!): File\n  deleteImage(input: DeleteFileInput!): File\n  createSignedUrl: String\n}\n","name":"GraphQL request","locationOffset":{"line":1,"column":1}};
  

    var names = {};
    function unique(defs) {
      return defs.filter(
        function(def) {
          if (def.kind !== 'FragmentDefinition') return true;
          var name = def.name.value
          if (names[name]) {
            return false;
          } else {
            names[name] = true;
            return true;
          }
        }
      )
    }
  

      module.exports = doc;
    


/***/ }),
/* 47 */
/***/ (function(module, exports) {


    var doc = {"kind":"Document","definitions":[{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Query"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"readRepo"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"name"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"Repo"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"listRepos"},"arguments":[],"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Repo"}}}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"Mutation"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"createRepo"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"Repo"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"updateRepo"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateRepoInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"Repo"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"deleteRepo"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"DeleteRepoInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"Repo"}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"Repo"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"id"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Int"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"node_id"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"name"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"full_name"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"description"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"private"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Boolean"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"updated_at"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"ModelRepoConnection"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"items"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Repo"}}}}},"directives":[]}]},{"kind":"InputObjectTypeDefinition","name":{"kind":"Name","value":"UpdateRepoInput"},"directives":[],"fields":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"name"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"description"},"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"private"},"type":{"kind":"NamedType","name":{"kind":"Name","value":"Boolean"}},"directives":[]}]},{"kind":"InputObjectTypeDefinition","name":{"kind":"Name","value":"DeleteRepoInput"},"directives":[],"fields":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"name"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}]}],"loc":{"start":0,"end":575}};
    doc.loc.source = {"body":"## Base\nextend type Query {\n  readRepo(name: String!): Repo\n  listRepos: [Repo!]\n}\n\ntype Mutation {\n  createRepo: Repo\n  updateRepo(input: UpdateRepoInput!): Repo\n  deleteRepo(input: DeleteRepoInput!): Repo\n}\n\n## Types\ntype Repo {\n  id: Int!\n  node_id: String!\n  name: String!\n  full_name: String!\n  description: String\n  private: Boolean!\n  updated_at: String!\n}\n\n## Query outputs\ntype ModelRepoConnection {\n  items: [Repo!]!\n}\n\n## Mutation inputs\ninput UpdateRepoInput {\n  name: String!\n  description: String\n  private: Boolean\n}\n\ninput DeleteRepoInput {\n  name: String!\n}\n","name":"GraphQL request","locationOffset":{"line":1,"column":1}};
  

    var names = {};
    function unique(defs) {
      return defs.filter(
        function(def) {
          if (def.kind !== 'FragmentDefinition') return true;
          var name = def.name.value
          if (names[name]) {
            return false;
          } else {
            names[name] = true;
            return true;
          }
        }
      )
    }
  

      module.exports = doc;
    


/***/ }),
/* 48 */
/***/ (function(module, exports) {


    var doc = {"kind":"Document","definitions":[{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"Query"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"readGithubUserAccessToken"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"code"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"InputValueDefinition","name":{"kind":"Name","value":"state"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]}],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"readGithubUser"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"GithubUser"}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"GithubUser"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"id"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Int"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"login"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"avatar_url"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"html_url"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"name"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"configuration"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"Configuration"}},"directives":[]}]}],"loc":{"start":0,"end":266}};
    doc.loc.source = {"body":"## Base\ntype Query {\n  readGithubUserAccessToken(code: String!, state: String!): String!\n  readGithubUser: GithubUser\n}\n\n## Types\ntype GithubUser {\n  id: Int!\n  login: String!\n  avatar_url: String!\n  html_url: String!\n  name: String\n  configuration: Configuration\n}\n","name":"GraphQL request","locationOffset":{"line":1,"column":1}};
  

    var names = {};
    function unique(defs) {
      return defs.filter(
        function(def) {
          if (def.kind !== 'FragmentDefinition') return true;
          var name = def.name.value
          if (names[name]) {
            return false;
          } else {
            names[name] = true;
            return true;
          }
        }
      )
    }
  

      module.exports = doc;
    


/***/ }),
/* 49 */
/***/ (function(module, exports) {


    var doc = {"kind":"Document","definitions":[{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Query"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"login"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"logout"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"refresh"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}},"directives":[]}]}],"loc":{"start":0,"end":83}};
    doc.loc.source = {"body":"## Base\nextend type Query {\n  login: String!\n  logout: String!\n  refresh: String\n}\n","name":"GraphQL request","locationOffset":{"line":1,"column":1}};
  

    var names = {};
    function unique(defs) {
      return defs.filter(
        function(def) {
          if (def.kind !== 'FragmentDefinition') return true;
          var name = def.name.value
          if (names[name]) {
            return false;
          } else {
            names[name] = true;
            return true;
          }
        }
      )
    }
  

      module.exports = doc;
    


/***/ }),
/* 50 */
/***/ (function(module, exports) {


    var doc = {"kind":"Document","definitions":[{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Query"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"readConfiguration"},"arguments":[],"type":{"kind":"NamedType","name":{"kind":"Name","value":"Configuration"}},"directives":[]}]},{"kind":"ObjectTypeExtension","name":{"kind":"Name","value":"Mutation"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"updateConfiguration"},"arguments":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"input"},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"UpdateConfigurationInput"}}},"directives":[]}],"type":{"kind":"NamedType","name":{"kind":"Name","value":"Configuration"}},"directives":[]}]},{"kind":"InputObjectTypeDefinition","name":{"kind":"Name","value":"UpdateConfigurationInput"},"directives":[],"fields":[{"kind":"InputValueDefinition","name":{"kind":"Name","value":"connectedRepos"},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}},"directives":[]}]},{"kind":"ObjectTypeDefinition","name":{"kind":"Name","value":"Configuration"},"interfaces":[],"directives":[],"fields":[{"kind":"FieldDefinition","name":{"kind":"Name","value":"id"},"arguments":[],"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},"directives":[]},{"kind":"FieldDefinition","name":{"kind":"Name","value":"connectedRepos"},"arguments":[],"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}},"directives":[]}]}],"loc":{"start":0,"end":291}};
    doc.loc.source = {"body":"## Base\nextend type Query {\n  readConfiguration: Configuration\n}\n\nextend type Mutation {\n  updateConfiguration(input: UpdateConfigurationInput!): Configuration\n}\n\ninput UpdateConfigurationInput {\n  connectedRepos: [String!]\n}\n\ntype Configuration {\n  id: String!\n  connectedRepos: [String!]\n}","name":"GraphQL request","locationOffset":{"line":1,"column":1}};
  

    var names = {};
    function unique(defs) {
      return defs.filter(
        function(def) {
          if (def.kind !== 'FragmentDefinition') return true;
          var name = def.name.value
          if (names[name]) {
            return false;
          } else {
            names[name] = true;
            return true;
          }
        }
      )
    }
  

      module.exports = doc;
    


/***/ }),
/* 51 */
/***/ (function(module, exports) {

module.exports = require("@middy/http-cors");

/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var allow_1 = __webpack_require__(53);
var http_errors_1 = __importDefault(__webpack_require__(4));
var node_fetch_1 = __importDefault(__webpack_require__(55));
var filterResponseHeaders_1 = __webpack_require__(56);
var getQueryString_1 = __webpack_require__(58);
var replaceAuthorizationHeader_1 = __webpack_require__(59);
function forwardGitRequest(event) {
    var _a;
    return __awaiter(this, void 0, void 0, function () {
        var httpMethod, pathParameters, queryStringParameters, requestBody, headers, isBase64Encoded, pathdomain, requestHeaders, queryString, base, url, response, responseHeaders, isSmartRequest, _b, _c, _d, _e;
        return __generator(this, function (_f) {
            switch (_f.label) {
                case 0:
                    allow_1.allow(event);
                    httpMethod = event.httpMethod, pathParameters = event.pathParameters, queryStringParameters = event.queryStringParameters, requestBody = event.body, headers = event.headers, isBase64Encoded = event.isBase64Encoded;
                    pathdomain = (_a = pathParameters) === null || _a === void 0 ? void 0 : _a.proxy;
                    if (!pathdomain)
                        throw new http_errors_1.default.BadRequest();
                    return [4 /*yield*/, replaceAuthorizationHeader_1.replaceAuthorizationHeader(headers)
                        // GitHub uses user-agent sniffing for git/* and changes its behavior which is frustrating
                    ];
                case 1:
                    requestHeaders = _f.sent();
                    // GitHub uses user-agent sniffing for git/* and changes its behavior which is frustrating
                    if (!requestHeaders['user-agent'] ||
                        !requestHeaders['user-agent'].startsWith('git/')) {
                        requestHeaders['user-agent'] = 'git/@isomorphic-git/cors-proxy';
                    }
                    requestHeaders.TE = 'Trailer';
                    queryString = getQueryString_1.getQueryString(queryStringParameters);
                    base = "https://" + pathdomain;
                    url = queryString ? base + "?" + queryString : base;
                    return [4 /*yield*/, node_fetch_1.default(url, {
                            // lambda-proxy binary request payloads are always converted to base64
                            // serverless-offline is not so we need to convert back to a buffer
                            // when running in api gateway
                            body: !requestBody
                                ? undefined
                                : isBase64Encoded
                                    ? Buffer.from(requestBody, 'base64')
                                    : requestBody,
                            headers: requestHeaders,
                            method: httpMethod,
                        })];
                case 2:
                    response = _f.sent();
                    if (response.status === 401)
                        throw new Error('No anonymous write access');
                    if (response.status !== 200 || response.statusText !== 'OK')
                        throw new Error('Proxy: github request failed');
                    responseHeaders = filterResponseHeaders_1.filterResponseHeaders(response);
                    if (response.redirected)
                        responseHeaders['x-redirected-url'] = response.url;
                    isSmartRequest = httpMethod === 'POST';
                    _b = {};
                    if (!isSmartRequest) return [3 /*break*/, 4];
                    _e = (_d = Buffer).from;
                    return [4 /*yield*/, response.buffer()];
                case 3:
                    _c = _e.apply(_d, [_f.sent()]).toString('base64');
                    return [3 /*break*/, 6];
                case 4: return [4 /*yield*/, response.text()];
                case 5:
                    _c = _f.sent();
                    _f.label = 6;
                case 6: return [2 /*return*/, (_b.body = _c,
                        _b.headers = responseHeaders,
                        _b.isBase64Encoded = isSmartRequest,
                        _b.statusCode = 200,
                        _b)];
            }
        });
    });
}
exports.forwardGitRequest = forwardGitRequest;


/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var lowerCaseObjectProps_1 = __webpack_require__(11);
function allow(event) {
    var _a, _b, _c, _d;
    var httpMethod = event.httpMethod, headers = event.headers, path = event.path, queryStringParameters = event.queryStringParameters;
    var lowerCasedHeaders = lowerCaseObjectProps_1.lowerCaseObjectProps(headers);
    if (httpMethod === 'OPTIONS' &&
        path.endsWith('/info/refs') &&
        (((_a = queryStringParameters) === null || _a === void 0 ? void 0 : _a.service) === 'git-upload-pack' ||
            ((_b = queryStringParameters) === null || _b === void 0 ? void 0 : _b.service) === 'git-receive-pack'))
        return true;
    if (httpMethod === 'GET' &&
        path.endsWith('/info/refs') &&
        (((_c = queryStringParameters) === null || _c === void 0 ? void 0 : _c.service) === 'git-upload-pack' ||
            ((_d = queryStringParameters) === null || _d === void 0 ? void 0 : _d.service) === 'git-receive-pack'))
        return true;
    if (httpMethod === 'OPTIONS' &&
        lowerCasedHeaders['access-control-request-headers'].includes('content-type') &&
        path.endsWith('git-upload-pack'))
        return true;
    if (httpMethod === 'POST' &&
        lowerCasedHeaders['content-type'] ===
            'application/x-git-upload-pack-request' &&
        path.endsWith('git-upload-pack'))
        return true;
    if (httpMethod === 'OPTIONS' &&
        lowerCasedHeaders['access-control-request-headers'].includes('content-type') &&
        path.endsWith('git-receive-pack'))
        return true;
    if (httpMethod === 'POST' &&
        lowerCasedHeaders['content-type'] ===
            'application/x-git-receive-pack-request' &&
        path.endsWith('git-receive-pack'))
        return true;
    throw new Error('Request not allowed');
}
exports.allow = allow;


/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.allowHeaders = [
    'accept-encoding',
    'accept-language',
    'accept',
    'access-control-allow-origin',
    'authorization',
    'cache-control',
    'connection',
    'content-length',
    'content-type',
    'dnt',
    'git-protocol',
    'pragma',
    'range',
    'referer',
    'user-agent',
    'x-authorization',
    'x-http-method-override',
    'x-requested-with',
    'cookie',
];


/***/ }),
/* 55 */
/***/ (function(module, exports) {

module.exports = require("node-fetch");

/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
var exposeHeaders_1 = __webpack_require__(57);
function filterResponseHeaders(response) {
    var e_1, _a;
    var responseHeaders = {};
    try {
        for (var exposeHeaders_2 = __values(exposeHeaders_1.exposeHeaders), exposeHeaders_2_1 = exposeHeaders_2.next(); !exposeHeaders_2_1.done; exposeHeaders_2_1 = exposeHeaders_2.next()) {
            var headername = exposeHeaders_2_1.value;
            if (headername === 'content-length')
                continue;
            if (response.headers.has(headername)) {
                responseHeaders[headername] = response.headers.get(headername);
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (exposeHeaders_2_1 && !exposeHeaders_2_1.done && (_a = exposeHeaders_2.return)) _a.call(exposeHeaders_2);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return responseHeaders;
}
exports.filterResponseHeaders = filterResponseHeaders;


/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.exposeHeaders = [
    'accept-ranges',
    'age',
    'cache-control',
    'content-length',
    'content-language',
    'content-type',
    'date',
    'etag',
    'expires',
    'last-modified',
    'pragma',
    'server',
    'vary',
    'x-github-request-id',
    'x-redirected-url',
];


/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
function getQueryString(queryStringParameters) {
    return queryStringParameters
        ? Object.entries(queryStringParameters).reduce(function (acc, _a) {
            var _b = __read(_a, 2), prop = _b[0], value = _b[1];
            acc = prop + "=" + value;
            return acc;
        }, '')
        : null;
}
exports.getQueryString = getQueryString;


/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var http_errors_1 = __importDefault(__webpack_require__(4));
var extractJwtFromAuth_1 = __webpack_require__(60);
var lowerCaseObjectProps_1 = __webpack_require__(11);
var verifyJwtAndGetUserDetails_1 = __webpack_require__(61);
function replaceAuthorizationHeader(headers) {
    return __awaiter(this, void 0, void 0, function () {
        var _a, authorization, cookie, rest, jwt, accessToken;
        return __generator(this, function (_b) {
            _a = lowerCaseObjectProps_1.lowerCaseObjectProps(headers), authorization = _a.authorization, cookie = _a.cookie, rest = __rest(_a, ["authorization", "cookie"]);
            jwt = extractJwtFromAuth_1.extractJwtFromAuth(authorization);
            try {
                accessToken = jwt ? verifyJwtAndGetUserDetails_1.verifyJwtAndGetUserDetails(jwt).accessToken : null;
            }
            catch (err) {
                throw new http_errors_1.default.Unauthorized();
            }
            return [2 /*return*/, __assign(__assign({}, rest), (accessToken
                    ? {
                        Authorization: "Basic " + Buffer.from(accessToken).toString('base64'),
                    }
                    : undefined))];
        });
    });
}
exports.replaceAuthorizationHeader = replaceAuthorizationHeader;


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function extractJwtFromAuth(bearerToken) {
    return bearerToken ? bearerToken.substring(7, bearerToken.length) : null;
}
exports.extractJwtFromAuth = extractJwtFromAuth;


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var services_1 = __webpack_require__(0);
var utils_1 = __webpack_require__(1);
var jwtManager = new services_1.JwtManager();
function verifyJwtAndGetUserDetails(jwt) {
    if (!jwt) {
        return {
            accessToken: '',
            owner: '',
        };
    }
    var _a = jwtManager.getJwtValues(jwt).body, encryptedAccessToken = _a.accessToken, iv = _a.iv, login = _a.login;
    return { accessToken: utils_1.decrypt(encryptedAccessToken, iv), owner: login };
}
exports.verifyJwtAndGetUserDetails = verifyJwtAndGetUserDetails;


/***/ }),
/* 62 */
/***/ (function(module, exports) {

module.exports = require("@middy/http-error-handler");

/***/ }),
/* 63 */
/***/ (function(module, exports) {

module.exports = require("@middy/http-header-normalizer");

/***/ }),
/* 64 */
/***/ (function(module, exports) {

module.exports = require("@middy/core");

/***/ })
/******/ ])));
//# sourceMappingURL=handlers.js.map